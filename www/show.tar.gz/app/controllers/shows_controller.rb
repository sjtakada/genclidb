class ShowsController < ApplicationController
  # show running-config
  def running_config
    # interface
    @interfaces = Interface.all

    # ip route
    @ipv4_route_nexthops = Ipv4RouteNexthop.all.sort do |a, b|
      a.ipv4_route.address <=> b.ipv4_route.address or
        b.ipv4_route.masklen <=> a.ipv4_route.masklen or
        a.nexthop_ipv4.ip_nexthop <=> b.nexthop_ipv4.ipo_nexthop
    end

    # access-list
    @acl_ipv4_stds = AclIpv4Std.all

    # router ospf
    @ospfv2s = Ospfv2.all
  end

  # show access-list
  def access_list
    @acl_ipv4_stds = AclIpv4Std.all
  end
end
